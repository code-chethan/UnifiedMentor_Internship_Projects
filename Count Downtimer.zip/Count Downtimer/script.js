let countdownInterval;
let totalSeconds;

function startTimer() {
    const hours = parseInt(document.getElementById("hours").value) || 0;
    const minutes = parseInt(document.getElementById("minutes").value) || 0;
    const seconds = parseInt(document.getElementById("seconds").value) || 0;

    totalSeconds = hours * 3600 + minutes * 60 + seconds;

    if (totalSeconds <= 0) {
        alert("Please enter a valid time.");
        return;
    }

    clearInterval(countdownInterval);
    updateTimerDisplay();
    countdownInterval = setInterval(countdown, 1000);
}

function countdown() {
    if (totalSeconds > 0) {
        totalSeconds--;
        updateTimerDisplay();
    } else {
        clearInterval(countdownInterval);
        alert("Time's up!");
    }
}

function updateTimerDisplay() {
    const hours = Math.floor(totalSeconds / 3600);
    const minutes = Math.floor((totalSeconds % 3600) / 60);
    const seconds = totalSeconds % 60;

    document.getElementById("timer").textContent =
        `${String(hours).padStart(2, "0")}:${String(minutes).padStart(2, "0")}:${String(seconds).padStart(2, "0")}`;
}

function resetTimer() {
    clearInterval(countdownInterval);
    totalSeconds = 0;
    document.getElementById("timer").textContent = "00:00:00";
    document.getElementById("hours").value = "";
    document.getElementById("minutes").value = "";
    document.getElementById("seconds").value = "";
}
