let allMusic = [
    {
        name: "Run - Red(Taylor's Version)",
        artist: "Taylor Swift & Ed Shreeran",
        img: "run",
        src: "run"
    },

    {
        name: "Perfect - Divide",
        artist: "Ed Shreeran",
        img: "perfect",
        src: "perfect"
    },

    {
        name: "Infinity - Feel Something",
        artist: "Jaymes Young",
        img: "infinity",
        src: "infinity"
    },

    {
        name: "No Lie - Now Dance",
        artist: "Sean Paul & Dua Lipa",
        img: "nolie",
        src: "nolie"
    },

    {
        name: "Sunflower - Spider-Man: Into the Spider-Verse",
        artist: "Post Malone & Swae Lee",
        img: "sunflower",
        src: "sunflower"
    },

    {
        name: "Heat Waves - Dreamland",
        artist: "Glass Animals",
        img: "heatwaves",
        src: "heatwaves"
    }
]